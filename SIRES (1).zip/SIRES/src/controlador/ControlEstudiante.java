/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Estudiante;
import modelo.RegistroEstudiante;
import vista.GUIEstudiante;
import vista.PanelBotones;
import vista.PanelEstudiante;

/**
 *
 * @author aaron
 */
public class ControlEstudiante implements ActionListener {

    private RegistroEstudiante registroEstudiante;
    private PanelEstudiante panelData;

    public ControlEstudiante(PanelEstudiante panelEstudiante) {
        registroEstudiante = new RegistroEstudiante();
        this.panelData = panelEstudiante;
    }

    public void actionPerformed(ActionEvent evento) {
        if (evento.getActionCommand().equalsIgnoreCase(PanelBotones.BTN_AGREGAR)) {
            if (panelData.getTxtCarnet().equalsIgnoreCase("")
                    || panelData.getTxtNombre().equalsIgnoreCase("")
                    || panelData.getTxtEdad() == 0) {
                GUIEstudiante.mensaje("Debe llenar todos los campos con información del estudiante!");
            } else {
                GUIEstudiante.mensaje(
                        registroEstudiante.addEstudiante(
                                new Estudiante(panelData.getTxtNombre(), panelData.getTxtEdad(), panelData.getTxtCarnet()))
                );
                panelData.limpiar();
            }
        }//Fin del if BTN-AGREGAR

        if (evento.getActionCommand().equalsIgnoreCase(PanelBotones.BTN_CONSULTAR)) {
          //  GUIEstudiante.mensaje(registroEstudiante.consultar(panelData.getTxtCarnet()) + "");
            panelData.setTxtCarnet(registroEstudiante.consultar(panelData.getTxtCarnet()).getCarnet());
            panelData.setTxtNombre(registroEstudiante.consultar(panelData.getTxtCarnet()).getNombre());
           // GUIEstudiante.mensaje(registroEstudiante.consultarAll());
        }

        if (evento.getActionCommand().equalsIgnoreCase(PanelBotones.BTN_SALIR)) {
            System.exit(0);
        }
    }//FIN DE SALIR

}
