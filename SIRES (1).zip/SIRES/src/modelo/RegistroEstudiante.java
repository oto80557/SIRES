/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author aaron
 */
public class RegistroEstudiante {

    ArrayList<Estudiante> listaEstudiante;

    public RegistroEstudiante() {
        listaEstudiante = new ArrayList<Estudiante>();
    }

    public String addEstudiante(Estudiante estudiante) {
        if (estudiante != null) {
            if (verificarCarnet(estudiante.getCarnet())) {
                listaEstudiante.add(estudiante);
                return "El estudiante fue agregado correctamente";
            } else {
                return "El estudiante se encuentra registrado!";
            }
        }
        return "El objeto es null!";
    }

    public boolean verificarCarnet(String carnet) {
        if (!carnet.equalsIgnoreCase("")) {
            if (listaEstudiante.size() != 0) {
                for (int index = 0; index < listaEstudiante.size(); index++) {
                    if (listaEstudiante.get(index).getCarnet().equals(carnet)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public Estudiante consultar(String carnet) {

        for (Estudiante estudiante : listaEstudiante) {
            if (estudiante.getCarnet().equalsIgnoreCase(carnet)) {
               
                return estudiante;
            }
        }

        return null;
    }
    
    public String consultarAll(){
        String salida="";
        for (Estudiante estudiante : listaEstudiante) {
            salida+=estudiante+"\n";
        }
        return salida;
    }

}
